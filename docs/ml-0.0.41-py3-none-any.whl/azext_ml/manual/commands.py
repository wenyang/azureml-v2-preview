# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands import CliCommandType


def load_command_table(self, _):
    from azext_ml.generated._client_factory import cf_ml_cl

    with self.command_group("ml model", client_factory=cf_ml_cl, is_experimental=True) as g:
        custom_tmpl = "azext_ml.manual.custom.model#{}"
        custom_model = CliCommandType(operations_tmpl=custom_tmpl)
        g.generic_update_command(
            "update",
            getter_name="_ml_model_show",
            getter_type=custom_model,
            setter_name="_ml_model_update",
            setter_type=custom_model,
        )
        g.custom_command("create", "ml_model_create")
        g.custom_command("show", "ml_model_show")
        g.custom_command("list", "ml_model_list")
        g.custom_command("delete", "ml_model_delete")

    with self.command_group("ml environment", client_factory=cf_ml_cl, is_experimental=True) as g:
        custom_tmpl = "azext_ml.manual.custom.environment#{}"
        custom_environment = CliCommandType(operations_tmpl=custom_tmpl)
        g.custom_command("create", "ml_environment_create")
        g.custom_command("show", "ml_environment_show")
        g.custom_command("list", "ml_environment_list")
        g.generic_update_command(
            "update",
            getter_name="ml_environment_show",
            getter_type=custom_environment,
            setter_name="_ml_environment_update",
            setter_type=custom_environment,
        )

    with self.command_group("ml data", client_factory=cf_ml_cl, is_experimental=True) as g:
        g.custom_command("create", "ml_data_create")
        g.custom_command("upload", "ml_data_upload")
        g.custom_command("show", "ml_data_show")
        g.custom_command("list", "ml_data_list")
        g.custom_command("delete", "ml_data_delete")

    with self.command_group("ml code", client_factory=cf_ml_cl, is_experimental=True) as g:
        g.custom_command("show", "ml_code_show")

    with self.command_group("ml job", client_factory=cf_ml_cl, is_experimental=True) as g:
        custom_tmpl = "azext_ml.manual.custom.job#{}"
        custom_job = CliCommandType(operations_tmpl=custom_tmpl)
        g.custom_command("download", "ml_job_download")
        g.custom_command("stream", "ml_job_stream")
        g.generic_update_command(
            "update",
            getter_name="ml_job_show",
            getter_type=custom_job,
            setter_name="_ml_job_update",
            setter_type=custom_job,
        )

    with self.command_group("ml endpoint", client_factory=cf_ml_cl, is_experimental=True) as g:
        g.custom_command("create", "ml_endpoint_create", supports_no_wait=True)
        g.custom_command("show", "ml_endpoint_show")
        g.custom_command("delete", "ml_endpoint_delete",
                         supports_no_wait=True, confirmation=True)
        g.custom_command("list", "ml_endpoint_list")
        g.custom_command("list-keys", "ml_endpoint_listkeys")
        g.custom_command("log", "ml_endpoint_get_deployment_logs")
        custom_tmpl = "azext_ml.manual.custom.endpoint#{}"
        custom_endpoint = CliCommandType(operations_tmpl=custom_tmpl)
        g.generic_update_command(
            "update",
            getter_name="ml_endpoint_update_show",
            getter_type=custom_endpoint,
            setter_name="ml_endpoint_update",
            setter_type=custom_endpoint,
            supports_no_wait=True,
        )
        g.custom_command("invoke", "ml_endpoint_invoke")
        g.custom_command("list-jobs", "ml_endpoint_list_jobs")

    with self.command_group("ml compute", client_factory=cf_ml_cl, is_experimental=True) as g:
        custom_tmpl = "azext_ml.manual.custom.compute#{}"
        custom_compute = CliCommandType(operations_tmpl=custom_tmpl)
        g.custom_command("create", "ml_compute_create", supports_no_wait=True)
        g.custom_command("show", "ml_compute_show")
        g.custom_command("list", "ml_compute_list")
        g.custom_command("delete", "ml_compute_delete", supports_no_wait=True)
        g.custom_command("start", "ml_compute_start", supports_no_wait=True)
        g.custom_command("stop", "ml_compute_stop", supports_no_wait=True)
        g.custom_command("restart", "ml_compute_restart",
                         supports_no_wait=True)
        g.custom_command("update", "ml_compute_update")
        g.custom_command("list-sizes", "ml_compute_list_sizes")
        g.custom_command("list-usage", "ml_compute_list_usage")
        g.generic_update_command(
            "update",
            getter_name="ml_compute_show",
            getter_type=custom_compute,
            setter_name="_ml_compute_update",
            setter_type=custom_compute,
        )

    with self.command_group("ml workspace", client_factory=cf_ml_cl, is_experimental=True) as g:
        custom_tmpl = "azext_ml.manual.custom.workspace#{}"
        custom_job = CliCommandType(operations_tmpl=custom_tmpl)
        g.custom_command("show", "ml_workspace_show")
        g.custom_command("list", "ml_workspace_list")
        g.custom_command("list-keys", "ml_workspace_listkeys")
        g.custom_command("sync-keys", "ml_workspace_synckeys")
        g.custom_command("create", "ml_workspace_create",
                         supports_no_wait=True)
        g.custom_command("delete", "ml_workspace_delete",
                         supports_no_wait=True)
        g.generic_update_command(
            "update",
            getter_name="ml_workspace_show",
            getter_type=custom_job,
            setter_name="ml_workspace_update",
            setter_type=custom_job,
        )

    with self.command_group("ml datastore", client_factory=cf_ml_cl, is_experimental=True) as g:
        g.custom_command("delete", "ml_datastore_delete")
        g.custom_command("create", "ml_datastore_create")
        g.custom_command("show", "ml_datastore_show")
        g.custom_command("list", "ml_datastore_list")
