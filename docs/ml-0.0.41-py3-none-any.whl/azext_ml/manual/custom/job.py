# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.ml.entities.job.job import Job
from marshmallow.utils import EXCLUDE
from .print_error import print_error_and_exit, print_warning
from webbrowser import open_new_tab

LEGACY_CREATE_ERROR = "Only tags and properties can be updated."
CREATE_ERROR = "(ServiceError) Received 409 from a service request"


def open_job_in_browser(job):
    try:
        studio_endpoint = None
        interactive_endpoints = job.interaction_endpoints
        if interactive_endpoints:
            studio_endpoint = interactive_endpoints.studio

        if studio_endpoint:
            open_new_tab(studio_endpoint)
        else:
            print_warning(
                "Option --web was specified, but no studio URI was found in the list of interactive endpoints."
            )

    except Exception as err:
        print_warning(err)


def ml_job_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    file=None,
    save_as=None,
    stream=False,
    web=False,
    params_override=[],
):

    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        if name is not None:
            params_override.append({"name": name})

        job = Job.load(path=file, workspace_scope=ml_client._workspace_scope, params_override=params_override)
        job = ml_client.jobs.create_or_update(job=job)
        if save_as:
            job.dump(save_as)

        if web:
            open_job_in_browser(job)

        if stream:
            ml_client.jobs.stream_logs(name=job.name)

        return _dump_job_with_warnings(job)

    except Exception as err:
        if str(err) is not None and (LEGACY_CREATE_ERROR in str(err) or CREATE_ERROR in str(err)):
            print_error_and_exit("A job with that name already exists. Use the --name option to provide a new name.")
        else:
            print_error_and_exit(err)


def ml_job_show(cmd, resource_group_name, workspace_name, name, web=False):

    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    try:
        job = ml_client.jobs.get(name)

        if web:
            open_job_in_browser(job)

        return _dump_job_with_warnings(job)
    except Exception as err:
        print_error_and_exit(err)


def ml_job_list(cmd, resource_group_name, workspace_name):

    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        job_list = ml_client.jobs.list()
        return list(map(lambda x: _dump_job_with_warnings(x), job_list))
    except Exception as err:
        print_error_and_exit(err)


def ml_job_download(cmd, resource_group_name, workspace_name, name, outputs=False, download_path=None):

    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        if not download_path:
            download_path = cmd.cli_ctx.local_context.current_dir
        return ml_client.jobs.download(name=name, logs_only=not outputs, download_path=download_path)
    except Exception as err:
        print_error_and_exit(err)


def ml_job_stream(cmd, resource_group_name, workspace_name, name):

    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    try:
        ml_client.jobs.stream_logs(name=name)
    except Exception as err:
        print_error_and_exit(err)


# This will only be used for generic update
def _ml_job_update(cmd, resource_group_name, workspace_name, web=False, parameters: Dict = None):

    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        # Set unknown to EXCLUDE so that marshmallow doesn't raise on dump only fields.
        job = Job._load(workspace_scope=ml_client._workspace_scope, data=parameters, unknown=EXCLUDE)

        updated_job = ml_client.jobs.create_or_update(job=job)

        if web:
            open_job_in_browser(updated_job)

        return _dump_job_with_warnings(updated_job)

    except Exception as err:
        print_error_and_exit(err)


def _dump_job_with_warnings(job: Job) -> Dict:
    try:
        return job._dump_yaml()  # type: ignore
    except Exception as err:
        print_warning("Failed to deserialize response: " + str(err))
        print_warning(str(job))
