# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.ml import MLClient
from typing import Dict
from azure.identity import AzureCliCredential
from azure.cli.core.profiles import ResourceType
from azure.cli.core.commands.client_factory import get_subscription_id, get_mgmt_service_client


def ml_workspace_list(cmd, resource_group_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.list()


def ml_workspace_show(cmd, resource_group_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.get(name=name)


def ml_workspace_listkeys(cmd, resource_group_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.list_keys(name=name)


def ml_workspace_synckeys(cmd, resource_group_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.sync_keys(name=name)


def ml_workspace_create(cmd, resource_group_name, file=None, no_wait=False, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.create(file=file, no_wait=no_wait, params_override=params_override)


def ml_workspace_update(cmd, resource_group_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.update(workspace_schema=parameters)


def ml_workspace_delete(cmd, resource_group_name, name, all_resources=False, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    ml_client = MLClient(
        subscription_id=subscription_id, resource_group_name=resource_group_name, credential=AzureCliCredential()
    )
    return ml_client.workspaces.delete(workspace_name=name, delete_dependent_resources=all_resources, no_wait=no_wait)
