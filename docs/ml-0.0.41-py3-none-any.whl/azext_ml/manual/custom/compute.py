# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.ml import MLClient
from typing import Dict
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.cli.core.commands.parameters import tags_type


def ml_compute_list(cmd, resource_group_name, workspace_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.list()


def ml_compute_show(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.get(name=name)


def ml_compute_create(cmd, resource_group_name,
                      workspace_name,
                      type=None,
                      name=None,
                      vnet_name=None,
                      subnet=None,
                      admin_username=None,
                      admin_password=None,
                      ssh_key_value=None,
                      file=None,
                      size=None,
                      no_wait=False,
                      user_tenant_id=None,
                      user_object_id=None,
                      node_public_ip=None,
                      min_node_count=0,
                      max_node_count=1,
                      node_idle_time_before_scale_down=None,
                      description=None,
                      tags: tags_type = None,
                      ):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    internal_compute = ml_client.computes.load(name=name, file=file,
                                               type=type, vnet_name=vnet_name, subnet=subnet, admin_username=admin_username,
                                               admin_password=admin_password,
                                               ssh_key_value=ssh_key_value,
                                               size=size, no_wait=no_wait,
                                               user_tenant_id=user_tenant_id,
                                               user_object_id=user_object_id,
                                               node_public_ip=node_public_ip,
                                               min_node_count=min_node_count,
                                               max_node_count=max_node_count,
                                               node_idle_time_before_scale_down=node_idle_time_before_scale_down,
                                               description=description,
                                               tags=tags)

    return ml_client.computes.create_or_update(internal_compute, no_wait=no_wait)


def ml_compute_delete(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.delete(name=name, action="Delete", no_wait=no_wait)


def ml_compute_start(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.start(name=name, no_wait=no_wait)


def ml_compute_stop(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.stop(name=name, no_wait=no_wait)


def ml_compute_restart(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.restart(name=name, no_wait=no_wait)


def ml_compute_list_sizes(cmd, resource_group_name, workspace_name, location, compute_type=None, recommended=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.list_sizes(location=location, compute_type=compute_type, recommended=recommended)


def ml_compute_list_usage(cmd, resource_group_name, workspace_name, location):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    return ml_client.computes.list_usage(location=location)


def _ml_compute_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    # Set unknown to EXCLUDE so that marshmallow doesn't raise on dump only fields.
    internal_compute = ml_client.computes.load(compute_schema=parameters)

    return ml_client.computes.create_or_update(internal_compute)
