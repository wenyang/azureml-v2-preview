# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param
from azure.cli.core.commands.parameters import tags_type


def compute_param(c):
    c.argument("name", options_list=["--name", "-n"],
               type=str, help="Name of the compute resource")


def load_compute_params(self):
    with self.argument_context("ml compute list") as c:
        add_common_params(c)

    with self.argument_context("ml compute show") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute create") as c:
        add_common_params(c)
        add_override_param(c)
        compute_param(c)
        c.argument("file", help="yaml file to create compute from.")
        c.argument("admin_username", help="Username for the VM.")
        c.argument("ssh_key_value", help="SSH public key.")
        c.argument("vnet_name", help="Resource id for vnet.")
        c.argument("subnet", help="subnet.")
        c.argument("type", help="compute type.")
        c.argument("description", help="description.")
        c.argument('tags', tags_type)
        c.argument("node_public_ip", help="Public ip of the node", )
        c.argument(
            "size", help="VM size to use for the compute target. More details can be found here: https://aka.ms/azureml-vm-details.")

    with self.argument_context("ml compute create", arg_group="AmlCompute") as c:
        c.argument("admin_password",
                   help="Password for the VM if authentication type is 'Password'")
        c.argument("min_node_count", help="Min node count")
        c.argument("max_node_count", help="Max node count")
        c.argument("node_idle_time_before_scale_down",
                   help="Wait time to scale down")

    with self.argument_context("ml compute create", arg_group="ComputeInstance") as c:
        c.argument("user_tenant_id", help="Tenant id")
        c.argument("user_object_id", help="Object Id")

    with self.argument_context("ml compute delete") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute list-sizes") as c:
        add_common_params(c)
        compute_param(c)
        c.argument("compute_type", help="Type of compute to filter by.")
        c.argument(
            "recommended", help="Specifies whether to return recommended vm sizes or all vm sizes.")

    with self.argument_context("ml compute list-usage") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute start") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute stop") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute restart") as c:
        add_common_params(c)
        compute_param(c)

    with self.argument_context("ml compute update") as c:
        add_common_params(c)
        compute_param(c)
