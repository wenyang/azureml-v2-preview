# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import pkg_resources
from azext_ml.manual.version import VERSION

REQUIREMENTS = []
with open("azext_ml/manual/requirements.txt", "rt") as fd:
    REQUIREMENTS = [str(requirement) for requirement in pkg_resources.parse_requirements(fd)]
DEPENDENCIES = ["azure-ml=={version}".format(version=VERSION)] + REQUIREMENTS
