# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_workspace_help():
    helps[
        "ml workspace"
    ] = """
        type: group
        short-summary: ml workspace
    """
    helps[
        "ml workspace list"
    ] = """
        type: command
        short-summary: "Lists all workspaces in a resource group."
    """
    helps[
        "ml workspace show"
    ] = """
            type: command
            short-summary: "Get the workspace with the specified name."
        """
    helps[
        "ml workspace delete"
    ] = """
            type: command
            short-summary: "Delete a workspace."
        """

    helps[
        "ml workspace create"
    ] = """
            type: command
            short-summary: "Create a workspace."
        """
    helps[
        "ml workspace list-keys"
    ] = """
            type: command
            short-summary: "List workspace keys for dependent resources such as storage, acr, and appinsights."
        """
    helps[
        "ml workspace sync-keys"
    ] = """
            type: command
            short-summary: "Sync workspace keys for dependent resources such as storage, acr, and appinsights."
        """

    helps[
        "ml workspace update"
    ] = """
            type: command
            short-summary: "Update a workspace (tags, display_name and description only)."
        """
