# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_compute_help():
    helps[
        "ml compute"
    ] = """
        type: group
        short-summary: ml compute.
    """
    helps[
        "ml compute show"
    ] = """
        type: group
        short-summary: Show ml compute.
    """
    helps[
        "ml compute update"
    ] = """
        type: group
        short-summary: Update ml compute (Tags, Description).
    """

    helps[
        "ml compute create"
    ] = """
        type: group
        short-summary: Create ml compute.
    """
    helps[
        "ml compute delete"
    ] = """
        type: group
        short-summary: Delete ml compute.
    """
    helps[
        "ml compute list"
    ] = """
        type: group
        short-summary: List ml computes in a workspace.
    """
    helps[
        "ml compute list-sizes"
    ] = """
        type: group
        short-summary: List ml compute sizes avaiable by location.
    """
    helps[
        "ml compute list-usage"
    ] = """
        type: group
        short-summary: List ml compute usage.
    """
    helps[
        "ml compute restart"
    ] = """
        type: group
        short-summary: Restart ml compute (ComputeInstance).
    """
    helps[
        "ml compute start"
    ] = """
        type: group
        short-summary: Start ml compute (ComputeInstance).
    """
    helps[
        "ml compute stop"
    ] = """
        type: group
        short-summary: Stop ml compute (ComputeInstance).
    """
