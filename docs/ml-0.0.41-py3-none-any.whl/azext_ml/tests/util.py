# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, List
from azure_devtools.scenario_tests import (
    RecordingProcessor,
)
from urllib.parse import urlparse
from itertools import product
import re


def assert_same(*yaml_objs: Dict, filter: List[str] = []):
    if len(yaml_objs) < 2:
        raise ValueError("the length of yaml object to compare should be at least 2")
    for yaml_obj, filter_val in product(yaml_objs, filter):
        if filter_val in yaml_obj:
            yaml_obj.pop(filter_val)
    base_to_compare = yaml_objs[0]
    for obj in yaml_objs[1:]:
        assert obj == base_to_compare


class PathReplacer(RecordingProcessor):
    def __init__(self, regex_string: str, replacement: str) -> None:
        self.regex_string = regex_string
        self.replacement = replacement

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            regex = re.compile(self.regex_string)

            assert regex.search(u.path)

            u = u._replace(path=regex.sub(self.replacement, u.path))

            request.uri = u.geturl()
            return request
        except Exception:
            return request


class ResourceGroupReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"resourceGroups/.+/provider", "resourceGroups/000000000000000/provider")


class WorkspaceNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"/workspaces/[^/]+", "/workspaces/000000000000000")


class DataNameReplacer(PathReplacer):
    def __init__(self) -> None:
        super().__init__(r"data/.+/versions", "data/000000000000000/versions")


class QueryStringParReplacer(RecordingProcessor):
    def __init__(self, parameter_name: str, replacement: str) -> None:
        self.parameter_name = parameter_name
        self.replacement = replacement

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert self.parameter_name in u.query
            u = u._replace(query=re.sub(self.parameter_name + r"=[^&]+", self.parameter_name + "=0000-00-00", u.query))
            request.uri = u.geturl()
            return request
        except Exception:
            return request


class CodeAssetNameReplacer(RecordingProcessor):
    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert "/codes/" in u.path
            u = u._replace(path=re.sub(r"/codes/[^/]+", "/codes/000000000000000", u.path))
            request.uri = u.geturl()
            return request
        except Exception:
            return request


class APIVersionReplacer(QueryStringParReplacer):
    def __init__(self) -> None:
        super().__init__("api-version", "0000-00-00")


class HeaderRemover(RecordingProcessor):
    def __init__(self, header: str) -> None:
        self.header = header

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            request.headers.pop(self.header, None)
            return request
        except Exception:
            return request

    def process_response(self, response):  # pylint: disable=no-self-use
        try:
            response["headers"].pop(self.header, None)
            return response
        except Exception:
            return response


class MD5HeaderRemover(HeaderRemover):
    def __init__(self) -> None:
        super().__init__("content-md5")


class UserAgentRemover(HeaderRemover):
    def __init__(self) -> None:
        super().__init__("user-agent")


class AzureBlobReplacer(RecordingProcessor):
    """
    Replace https://storagea5jlura67u2una.blob.core.windows.net/azureml-blobstore-09911d39-adba-4943-950e-1c1540bf2711/az-ml-artifacts/7e05d06d-2462-446d-a683-61aa383be019/python/sample1.csv
    to https://xxxxxxxxxxxxxxxxxxxxxx.blob.core.windows.net/azureml-blobstore-00000000-0000-0000-0000-000000000000/az-ml-artifacts/00000000-0000-0000-0000-00000000000/python/sample1.csv
    """

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            storage_account, *rest = u.netloc.split(".")
            assert ".".join(rest) == "blob.core.windows.net"
            empty, blobstore, container, folder, *path = u.path.split("/")
            assert container == "az-ml-artifacts"
            u = u._replace(netloc="xxxxxxxxxxxxxxxxxxxxxx." + ".".join(rest))
            u = u._replace(
                path="/".join(
                    [
                        empty,
                        "azureml-blobstore-00000000-0000-0000-0000-000000000000",
                        container,
                        "00000000-0000-0000-0000-00000000000",
                    ]
                    + path
                )
            )
            request.uri = u.geturl()
            return request
        except Exception:
            return request
