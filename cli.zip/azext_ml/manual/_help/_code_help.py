# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_code_help():
    helps['ml code'] = """
        type: group
        short-summary: ml code
    """
