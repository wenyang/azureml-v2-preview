# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_model_help():
    helps['ml model'] = """
        type: group
        short-summary: ml model
    """
