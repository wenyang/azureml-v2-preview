# Azure CLI ml Extension #
This is the extension for ml

### How to use ###
Install this extension using the below CLI command
```
az extension add --name ml
```

### Included Features ###
#### ml endpoint ####
#### ml datastore ####
#### ml job ####
#### ml workspace ####
#### ml usage ####
#### ml vm-size ####
#### ml compute quota ####
#### ml compute ####
#### ml sku ####